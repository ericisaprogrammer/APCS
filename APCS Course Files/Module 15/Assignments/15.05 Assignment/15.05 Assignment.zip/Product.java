/* Purpose: To be a review for everything learned in module 15
 * Author: Eric Osgood
 * Date: April 25th, 2016
 */
public interface Product
{
    public String getName();
    public double getCost();
}