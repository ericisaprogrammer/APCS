/* Purpose: To demonstrate the basic principals for inheritance
 * Author: Eric Osgood
 * Date: March 21st, 2016
 */
public class Cube extends Box
{
    Cube(int w)
    {
        super(w, w, w);
    }
}